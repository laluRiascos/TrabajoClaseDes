
/*
//PropTypes
import PropTypes from 'prop-types';
const FirstApp = ({title,sum}) => {
  return<>
    <h1>{title}</h1>
    <span>{sum}</span>
  </>
}
FirstApp.PropTypes = {
  title: PropTypes.string.isRequired,
  sum: PropTypes.number.isRequired
}
FirstApp.defaultProps = {
  title: 'No hay titulos',
  sum: 300
}
export default FirstApp;
*/

//_____________________________________________________________

/*
//Functions.
const FirstApp = ({value}) => {

  const handleAdd = () =>{
    console.log('calling handleAdd')
  }
    return (
      <>
      <h1> Counter </h1>
      <span> {value} </span>
      <button onClick={ () => handleAdd()}> +1 </button>
      </>
    )
  }
  
  export default FirstApp;
  */

  //_____________________________________________________________

  
  //Functions with Hooks. 
  //Challenge ##
  import {useState} from "react"

  const FirstApp = ({value}) => {

  const [counter, setCounter] = useState(value)

  const handleAdd = () =>{
    setCounter(counter + 1)
    console.log(counter)
  }
  const handleMinus = () =>{
    setCounter(counter - 1)
    console.log(counter)
  }
  const handleReset = () =>{
    setCounter(value)
    console.log(counter)
  }
    return (
      <>
      <h1> Counter </h1>
      <span> {counter} </span>
      <button onClick={ () => handleAdd()}> +1 </button>
      <button onClick={() => handleMinus()}> -1 </button>
      <button onClick={() => handleReset()}> Reset </button>
      </>
    ) 
  }

  export default FirstApp;