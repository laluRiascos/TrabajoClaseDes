import FirstApp from './FirstApp.jsx'

const App = () => {
  return (
    <>
    <FirstApp value={1}></FirstApp>
    </>
  )
}

export default App;